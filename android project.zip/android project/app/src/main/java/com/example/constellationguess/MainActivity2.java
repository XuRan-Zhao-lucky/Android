package com.example.constellationguess;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    private TextView starIntro;
    private ImageView starImg;
    private  TextView textView,textView1;
    /*private int [] wenzi={
            R.string.白羊座,
            R.string.金牛座,
            R.string.双子座,
            R.string.巨蟹座,
            R.string.狮子座,
            R.string.处女座,
            R.string.天秤座,
            R.string.天蝎座,
            R.string.射手座,
            R.string.摩羯座,
            R.string.水瓶座,
            R.string.双鱼座
    };
    private int[]imges={
            R.drawable.baiyang,
            R.drawable.jinniu,
            R.drawable.shuangzi,
            R.drawable.juxie,
            R.drawable.shizi,
            R.drawable.chunv,
            R.drawable.tiancheng,
            R.drawable.tianxie,
            R.drawable.sheshou,
            R.drawable.mojie,
            R.drawable.shuiping,
            R.drawable.shuangyu
    };*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        textView=(TextView)findViewById(R.id.tv1);
        textView1=(TextView)findViewById(R.id.tv2);

        Intent Intent=getIntent();//获取当前的intent
        String name=Intent.getStringExtra("name");
        String date=Intent.getStringExtra("date");

        textView.setText(name);
        textView1.setText(date);

        int m=Intent.getIntExtra("month",0);
        int d=Intent.getIntExtra("day",0);


        LinearLayout mainLinerLayout = (LinearLayout) this.findViewById(R.id.MyTable);
        TextView text=new TextView(this);
        ImageView img=new ImageView(this);


            if((m ==3 && d>20) || (m ==4 && d<21)) {
                img.setImageResource(R.drawable.baiyang);//动态生成图片框
                text.setText(R.string.白羊座);//动态生成文本框
                mainLinerLayout.addView(img);
                mainLinerLayout.addView(text);
            }if((m ==4 && d>20) || (m ==5 && d<21)){
                img.setImageResource(R.drawable.jinniu);//动态生成图片框
                text.setText( R.string.金牛座);//动态生成文本框
                mainLinerLayout.addView(img);
                mainLinerLayout.addView(text);
            }if((m ==5 && d>20) || (m ==6 && d<22)){
                img.setImageResource(R.drawable.shuangzi);//动态生成图片框
                text.setText(R.string.双子座);//动态生成文本框
                mainLinerLayout.addView(img);
                mainLinerLayout.addView(text);
            }if((m ==6 && d>21) || (m ==7 && d<23)){
                img.setImageResource(R.drawable.juxie);//动态生成图片框
                text.setText(R.string.巨蟹座);//动态生成文本框
                mainLinerLayout.addView(img);
                mainLinerLayout.addView(text);
            } if((m ==7 && d>22) || (m ==8 && d<23)){
                img.setImageResource( R.drawable.shizi);//动态生成图片框
                text.setText(R.string.狮子座);//动态生成文本框
                mainLinerLayout.addView(img);
                mainLinerLayout.addView(text);
            } if((m ==8 && d>22) || (m ==9 && d<23)){
                img.setImageResource(R.drawable.chunv);//动态生成图片框
                text.setText(R.string.处女座);//动态生成文本框
                mainLinerLayout.addView(img);
                mainLinerLayout.addView(text);
            } if((m ==9 && d>22) || (m ==10 && d<23)){
                img.setImageResource(R.drawable.tiancheng);//动态生成图片框
                text.setText(R.string.天秤座);//动态生成文本框
                mainLinerLayout.addView(img);
                mainLinerLayout.addView(text);
            } if((m ==10 && d>22) || (m ==11 && d<22)){
               img.setImageResource(R.drawable.tianxie);//动态生成图片框
                text.setText(R.string.天蝎座);//动态生成文本框
                mainLinerLayout.addView(img);
                mainLinerLayout.addView(text);
            } if((m ==11 && d>21) || (m ==12 && d<22)){
                img.setImageResource(R.drawable.sheshou);//动态生成图片框
                text.setText(R.string.射手座);//动态生成文本框
                mainLinerLayout.addView(img);
                mainLinerLayout.addView(text);
            } if((m ==12 && d>21) || (m ==1 && d<20)){
                img.setImageResource(R.drawable.mojie);//动态生成图片框
                text.setText(R.string.摩羯座);//动态生成文本框
                mainLinerLayout.addView(img);
                mainLinerLayout.addView(text);
            }if((m ==2 && d>18) || (m ==3 && d<21)) {
                img.setImageResource(R.drawable.shuangyu);//动态生成图片框
                text.setText(R.string.双鱼座);//动态生成文本框
                mainLinerLayout.addView(img);
                mainLinerLayout.addView(text);
            }
             if((m ==1 && d>19) || (m ==2 && d<19)){
                img.setImageResource(R.drawable.shuiping);//动态生成图片框
                text.setText(R.string.水瓶座);//动态生成文本框
                mainLinerLayout.addView(img);
                mainLinerLayout.addView(text);
            }
    }
}