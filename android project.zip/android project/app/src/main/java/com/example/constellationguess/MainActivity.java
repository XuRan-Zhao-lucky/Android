package com.example.constellationguess;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private Button bt;
    private int year,day,month;
    private EditText et_name;
    private String date;
    private DatePicker DatePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //将activity_xml里的跟mainactivity里的东西绑定起来
        bt = (Button) findViewById(R.id.welcombutten);//绑定按钮
        et_name=(EditText) findViewById(R.id.textview);
        DatePicker=(DatePicker)findViewById(R.id.datePickerView);

        //获取当前已经new出来的对象，如果没有，则调用构造方法
        Calendar calendar= Calendar.getInstance();

        year=calendar.get(Calendar.YEAR);
        month=calendar.get(Calendar.MONTH);
        day=calendar.get(Calendar.DATE);

        //日期调用init，重写onDateChanged方法
        DatePicker.init(year,month,day,new DatePicker.OnDateChangedListener(){
            @Override
            public void onDateChanged(DatePicker view, int year1, int monthOfYear, int dayOfMonth) {
                date = String.format("%d年%d月%d日", year1, monthOfYear+1, dayOfMonth);
                year=year1;
                month=monthOfYear+1;
                day=dayOfMonth;
            }
        });

        Intent intent =new Intent(this,MainActivity2.class);

        bt.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                intent.putExtra("name",et_name.getText().toString().trim());
                intent.putExtra("date",date);
                intent.putExtra("month",month);
                intent.putExtra("day",day);
                startActivity(intent); //启动
            }
        });
    }
}